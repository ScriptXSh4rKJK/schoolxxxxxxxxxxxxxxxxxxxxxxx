# Základní škola Žďár nad Sázavou - School Website

## Overview

This is a static website for Základní škola (Elementary School) Žďár nad Sázavou, a Czech elementary school. The website provides information about the school, news, schedules, teachers, and resources for students and parents. It's built as a multi-page static HTML website with modern CSS styling and JavaScript interactivity.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Static HTML Structure**: Multi-page website with 8 main pages (index, news, schedule, teachers, students, parents, about, contacts)
- **Responsive Design**: Mobile-first approach with hamburger navigation for mobile devices
- **CSS Architecture**: Single stylesheet (style.css) using CSS custom properties for consistent theming
- **JavaScript Enhancement**: Progressive enhancement with script.js handling interactive features like mobile navigation, galleries, forms, and animations

### Design System
- **Color Scheme**: Blue-based palette with primary color #2c5aa0, inspired by educational institutions
- **Typography**: Roboto font family from Google Fonts with multiple weights (300, 400, 500, 700)
- **Layout**: Container-based layout with consistent spacing and responsive grid system
- **Navigation**: Fixed header with desktop horizontal menu and mobile hamburger menu

### Component Structure
- **Header Navigation**: Consistent across all pages with active state indicators
- **Breadcrumb Navigation**: Shows current page location for better user orientation
- **Mobile-First Responsive**: Hamburger menu for mobile devices with smooth transitions
- **Interactive Elements**: JavaScript-powered features including sliders, forms, FAQ sections, and smooth scrolling

### Content Management
- **Static Content**: All content is hardcoded in HTML files
- **Czech Language**: Entire website is in Czech (cs lang attribute)
- **School Sections**: Organized into logical sections for different user groups (students, parents, teachers)

## External Dependencies

### CDN Resources
- **Font Awesome 6.4.0**: Icon library from cdnjs.cloudflare.com for UI icons
- **Google Fonts**: Roboto font family for consistent typography
- **No JavaScript Frameworks**: Vanilla JavaScript approach for all interactivity

### Browser Compatibility
- **Modern CSS**: Uses CSS custom properties and modern layout techniques
- **Progressive Enhancement**: Core functionality works without JavaScript
- **Responsive Images**: Optimized for various device sizes and screen densities

### No Backend Dependencies
- **Pure Frontend**: No server-side processing required
- **No Database**: All content is static HTML
- **No Authentication**: Public website with no user accounts or login system