/**
 * Hlavní JavaScript soubor pro Základní školu Žďár nad Sázavou
 * Obsahuje všechny interaktivní funkce webu
 */

// ====================================
// HLAVNÍ INICIALIZACE
// ====================================

document.addEventListener('DOMContentLoaded', function() {
    // Inicializace všech komponent
    initMobileNavigation();
    initGallerySlider();
    initBackToTop();
    initNewsArticles();
    initNewsFilters();
    initFAQ();
    initContactForm();
    initSchedule();
    initPagination();
    initSmoothScrolling();
    initAnimations();
});

// ====================================
// MOBILNÍ NAVIGACE
// ====================================

function initMobileNavigation() {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-menu a');

    if (!navToggle || !navMenu) return;

    // Toggle menu při kliknutí na hamburger
    navToggle.addEventListener('click', function() {
        navToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
        
        // Prevence scrollování pozadí při otevřeném menu
        if (navMenu.classList.contains('active')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    });

    // Zavření menu při kliknutí na odkaz
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    });

    // Zavření menu při kliknutí mimo menu
    document.addEventListener('click', function(e) {
        if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    // Zavření menu při změně velikosti okna
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
}

// ====================================
// FOTOGALERIE SLIDER
// ====================================

function initGallerySlider() {
    const galleryContainer = document.querySelector('.gallery-container');
    const slides = document.querySelectorAll('.gallery-slide');
    const prevBtn = document.querySelector('.gallery-prev');
    const nextBtn = document.querySelector('.gallery-next');

    if (!galleryContainer || slides.length === 0) return;

    let currentSlide = 0;
    const totalSlides = slides.length;

    function showSlide(index) {
        // Skrytí všech slidů
        slides.forEach(slide => {
            slide.classList.remove('active');
        });

        // Zobrazení aktuálního slidu
        slides[index].classList.add('active');
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % totalSlides;
        showSlide(currentSlide);
    }

    function prevSlide() {
        currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
        showSlide(currentSlide);
    }

    // Event listenery pro tlačítka
    if (nextBtn) {
        nextBtn.addEventListener('click', nextSlide);
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', prevSlide);
    }

    // Automatické přepínání každých 5 sekund
    let autoSlideInterval = setInterval(nextSlide, 5000);

    // Zastavení automatického přepínání při hover
    galleryContainer.addEventListener('mouseenter', () => {
        clearInterval(autoSlideInterval);
    });

    galleryContainer.addEventListener('mouseleave', () => {
        autoSlideInterval = setInterval(nextSlide, 5000);
    });

    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowLeft') {
            prevSlide();
        } else if (e.key === 'ArrowRight') {
            nextSlide();
        }
    });

    // Touch/swipe podpora pro mobily
    let startX = 0;
    let endX = 0;

    galleryContainer.addEventListener('touchstart', function(e) {
        startX = e.touches[0].clientX;
    });

    galleryContainer.addEventListener('touchend', function(e) {
        endX = e.changedTouches[0].clientX;
        const difference = startX - endX;

        if (Math.abs(difference) > 50) { // Minimální vzdálenost pro swipe
            if (difference > 0) {
                nextSlide();
            } else {
                prevSlide();
            }
        }
    });
}

// ====================================
// TLAČÍTKO NAHORU
// ====================================

function initBackToTop() {
    const backToTopBtn = document.getElementById('backToTop');
    
    if (!backToTopBtn) return;

    // Zobrazení/skrytí tlačítka při scrollování
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTopBtn.classList.add('visible');
        } else {
            backToTopBtn.classList.remove('visible');
        }
    });

    // Smooth scroll nahoru při kliknutí
    backToTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// ====================================
// AKTUALITY - ROZBALOVÁNÍ ČLÁNKŮ
// ====================================

function initNewsArticles() {
    const readMoreBtns = document.querySelectorAll('.read-more-btn');

    readMoreBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const article = this.closest('.news-article');
            const excerpt = article.querySelector('.article-excerpt');
            const fullText = article.querySelector('.article-full');
            const btnIcon = this.querySelector('i');

            if (fullText.style.display === 'none' || fullText.style.display === '') {
                // Rozbalení článku
                fullText.style.display = 'block';
                excerpt.style.display = 'none';
                this.innerHTML = 'Skrýt článek <i class="fas fa-chevron-up"></i>';
                this.classList.add('expanded');
            } else {
                // Sbalení článku
                fullText.style.display = 'none';
                excerpt.style.display = 'block';
                this.innerHTML = 'Zobrazit celý článek <i class="fas fa-chevron-down"></i>';
                this.classList.remove('expanded');
            }
        });
    });
}

// ====================================
// AKTUALITY - FILTRY KATEGORIÍ
// ====================================

function initNewsFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const newsArticles = document.querySelectorAll('.news-article');

    if (filterBtns.length === 0) return;

    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const category = this.getAttribute('data-category');

            // Aktualizace aktivního tlačítka
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            // Filtrace článků
            newsArticles.forEach(article => {
                const articleCategory = article.getAttribute('data-category');
                
                if (category === 'all' || articleCategory === category) {
                    article.style.display = 'block';
                    // Animace objevení
                    setTimeout(() => {
                        article.style.opacity = '1';
                        article.style.transform = 'translateY(0)';
                    }, 100);
                } else {
                    article.style.opacity = '0';
                    article.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        article.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
}

// ====================================
// FAQ ROZBALOVÁNÍ
// ====================================

function initFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');

        if (!question || !answer) return;

        question.addEventListener('click', function() {
            const isOpen = item.classList.contains('open');

            // Zavření všech ostatních FAQ položek
            faqItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('open');
                }
            });

            // Toggle aktuální položky
            if (isOpen) {
                item.classList.remove('open');
            } else {
                item.classList.add('open');
            }
        });
    });
}

// ====================================
// KONTAKTNÍ FORMULÁŘ
// ====================================

function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    const formSuccess = document.getElementById('formSuccess');

    if (!contactForm) return;

    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();

        // Validace formuláře
        if (validateForm()) {
            // Simulace odeslání formuláře
            submitForm();
        }
    });

    function validateForm() {
        const requiredFields = contactForm.querySelectorAll('[required]');
        let isValid = true;

        requiredFields.forEach(field => {
            const formGroup = field.closest('.form-group');
            const errorMessage = formGroup.querySelector('.error-message');

            // Vyčištění předchozích chyb
            formGroup.classList.remove('error');
            if (errorMessage) {
                errorMessage.style.display = 'none';
            }

            // Validace jednotlivých polí
            if (!field.value.trim()) {
                showFieldError(formGroup, 'Toto pole je povinné');
                isValid = false;
            } else if (field.type === 'email' && !isValidEmail(field.value)) {
                showFieldError(formGroup, 'Zadejte platnou emailovou adresu');
                isValid = false;
            } else if (field.type === 'checkbox' && !field.checked) {
                showFieldError(formGroup, 'Musíte souhlasit se zpracováním osobních údajů');
                isValid = false;
            }
        });

        return isValid;
    }

    function showFieldError(formGroup, message) {
        formGroup.classList.add('error');
        const errorMessage = formGroup.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.textContent = message;
            errorMessage.style.display = 'block';
        }
    }

    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    function submitForm() {
        // Zobrazení loading stavu
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Odesílá se...';
        submitBtn.disabled = true;

        // Simulace odeslání (v reálné aplikaci by zde byl AJAX request)
        setTimeout(() => {
            // Skrytí formuláře a zobrazení úspěšné zprávy
            contactForm.style.display = 'none';
            if (formSuccess) {
                formSuccess.classList.add('show');
            }

            // Reset formuláře
            contactForm.reset();
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;

            // Zobrazení formuláře po 5 sekundách
            setTimeout(() => {
                contactForm.style.display = 'block';
                if (formSuccess) {
                    formSuccess.classList.remove('show');
                }
            }, 5000);
        }, 2000);
    }
}

// ====================================
// ROZVRH HODIN
// ====================================

function initSchedule() {
    const classSelect = document.getElementById('classSelect');
    
    if (!classSelect) return;

    // Simulace dat rozvrhů pro různé třídy
    const scheduleData = {
        '1a': generateScheduleData('1.A', ['Český jazyk', 'Matematika', 'Přírodověda', 'Výtvarná výchova', 'Hudební výchova', 'Tělesná výchova']),
        '1b': generateScheduleData('1.B', ['Český jazyk', 'Matematika', 'Přírodověda', 'Výtvarná výchova', 'Hudební výchova', 'Tělesná výchova']),
        '2a': generateScheduleData('2.A', ['Český jazyk', 'Matematika', 'Přírodověda', 'Vlastivěda', 'Výtvarná výchova', 'Hudební výchova', 'Tělesná výchova']),
        '5a': generateScheduleData('5.A', ['Český jazyk', 'Matematika', 'Anglický jazyk', 'Přírodověda', 'Vlastivěda', 'Výtvarná výchova', 'Hudební výchova', 'Tělesná výchova', 'Pracovní činnosti']),
        '6a': generateScheduleData('6.A', ['Český jazyk', 'Matematika', 'Anglický jazyk', 'Dějepis', 'Zeměpis', 'Přírodopis', 'Fyzika', 'Výtvarná výchova', 'Hudební výchova', 'Tělesná výchova']),
        '9a': generateScheduleData('9.A', ['Český jazyk', 'Matematika', 'Anglický jazyk', 'Dějepis', 'Zeměpis', 'Přírodopis', 'Fyzika', 'Chemie', 'Občanská výchova', 'Informatika', 'Tělesná výchova'])
    };

    classSelect.addEventListener('change', function() {
        const selectedClass = this.value;
        updateScheduleTable(scheduleData[selectedClass] || scheduleData['5a']);
    });

    function generateScheduleData(className, subjects) {
        // Generování ukázkového rozvrhu
        const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
        const teachers = ['Mgr. Novotná', 'Mgr. Svoboda', 'Mgr. Černá', 'Mgr. Procházka', 'Mgr. Sporák', 'Mgr. Melodická'];
        const rooms = ['12', '15', '8', 'Lab', 'TV', 'HV', 'VV', 'D1'];
        
        const schedule = {};
        
        days.forEach(day => {
            schedule[day] = [];
            for (let hour = 1; hour <= 6; hour++) {
                if (Math.random() > 0.1) { // 90% šance na hodinu
                    const subject = subjects[Math.floor(Math.random() * subjects.length)];
                    const teacher = teachers[Math.floor(Math.random() * teachers.length)];
                    const room = rooms[Math.floor(Math.random() * rooms.length)];
                    
                    schedule[day].push({
                        hour: hour,
                        subject: subject,
                        teacher: teacher,
                        room: room
                    });
                } else {
                    schedule[day].push(null); // Prázdná hodina
                }
            }
        });
        
        return schedule;
    }

    function updateScheduleTable(scheduleData) {
        const tableBody = document.querySelector('.schedule-table tbody');
        if (!tableBody || !scheduleData) return;

        // Vyčištění stávající tabulky (kromě break-row)
        const rows = tableBody.querySelectorAll('tr:not(.break-row)');
        rows.forEach(row => row.remove());

        const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
        const timeSlots = [
            { hour: 1, time: '8:00 - 8:45' },
            { hour: 2, time: '8:55 - 9:40' },
            { hour: 3, time: '10:00 - 10:45' },
            { hour: 4, time: '10:55 - 11:40' },
            { hour: 5, time: '11:50 - 12:35' },
            { hour: 6, time: '12:45 - 13:30' }
        ];

        timeSlots.forEach((timeSlot, index) => {
            const row = document.createElement('tr');
            
            // Časový slot
            const timeCell = document.createElement('td');
            timeCell.className = 'time-slot';
            timeCell.innerHTML = `
                <div class="lesson-number">${timeSlot.hour}</div>
                <div class="lesson-time">${timeSlot.time}</div>
            `;
            row.appendChild(timeCell);

            // Hodiny pro každý den
            days.forEach(day => {
                const cell = document.createElement('td');
                cell.className = 'lesson-cell';
                
                const lesson = scheduleData[day] && scheduleData[day][index];
                if (lesson) {
                    cell.innerHTML = `
                        <div class="subject">${lesson.subject}</div>
                        <div class="teacher">${lesson.teacher}</div>
                        <div class="room">${lesson.room}</div>
                    `;
                } else {
                    cell.classList.add('empty');
                    cell.innerHTML = '<div class="no-lesson">—</div>';
                }
                
                row.appendChild(cell);
            });

            // Vložení velkého přestávky po 2. hodině
            if (index === 1) {
                tableBody.appendChild(row);
                const breakRow = document.createElement('tr');
                breakRow.className = 'break-row';
                breakRow.innerHTML = `
                    <td class="time-slot break">
                        <div class="break-text">Velká přestávka</div>
                        <div class="lesson-time">9:40 - 10:00</div>
                    </td>
                    <td colspan="5" class="break-cell"></td>
                `;
                tableBody.appendChild(breakRow);
            } else {
                tableBody.appendChild(row);
            }
        });
    }
}

// ====================================
// PAGINACE
// ====================================

function initPagination() {
    const paginationBtns = document.querySelectorAll('.pagination-number');
    const prevBtn = document.querySelector('.pagination-btn.prev');
    const nextBtn = document.querySelector('.pagination-btn.next');

    if (paginationBtns.length === 0) return;

    let currentPage = 1;
    const totalPages = paginationBtns.length;

    function updatePagination(page) {
        // Aktualizace aktivní stránky
        paginationBtns.forEach(btn => {
            btn.classList.remove('active');
            if (parseInt(btn.textContent) === page) {
                btn.classList.add('active');
            }
        });

        // Aktualizace tlačítek prev/next
        if (prevBtn) {
            prevBtn.disabled = page === 1;
        }
        if (nextBtn) {
            nextBtn.disabled = page === totalPages;
        }

        // Zde by se načetl obsah pro danou stránku
        loadPageContent(page);
    }

    // Event listenery pro čísla stránek
    paginationBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const page = parseInt(this.textContent);
            currentPage = page;
            updatePagination(page);
        });
    });

    // Event listenery pro prev/next tlačítka
    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            if (currentPage > 1) {
                currentPage--;
                updatePagination(currentPage);
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            if (currentPage < totalPages) {
                currentPage++;
                updatePagination(currentPage);
            }
        });
    }

    function loadPageContent(page) {
        // Simulace načítání obsahu
        const articles = document.querySelectorAll('.news-article');
        const articlesPerPage = 3;
        const startIndex = (page - 1) * articlesPerPage;
        const endIndex = startIndex + articlesPerPage;

        articles.forEach((article, index) => {
            if (index >= startIndex && index < endIndex) {
                article.style.display = 'block';
            } else {
                article.style.display = 'none';
            }
        });

        // Scroll na začátek obsahu
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
            mainContent.scrollIntoView({ behavior: 'smooth' });
        }
    }
}

// ====================================
// SMOOTH SCROLLING
// ====================================

function initSmoothScrolling() {
    // Smooth scrolling pro kotvy
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href === '#') {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
                return;
            }

            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                
                // Offset pro fixní header
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = target.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// ====================================
// ANIMACE A EFEKTY
// ====================================

function initAnimations() {
    // Intersection Observer pro animace při scrollování
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);

    // Pozorování elementů pro animace
    const animatedElements = document.querySelectorAll('.news-card, .teacher-card, .link-card, .service-card, .stat-item');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });

    // CSS pro animace
    const style = document.createElement('style');
    style.textContent = `
        .animate-in {
            opacity: 1 !important;
            transform: translateY(0) !important;
        }
    `;
    document.head.appendChild(style);

    // Parallax efekt pro hero sekci
    const hero = document.querySelector('.hero');
    if (hero) {
        window.addEventListener('scroll', function() {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;
            hero.style.transform = `translateY(${rate}px)`;
        });
    }

    // Hover efekty pro karty
    const cards = document.querySelectorAll('.news-card, .teacher-card, .link-card, .service-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px)';
        });

        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
}

// ====================================
// UTILITY FUNKCE
// ====================================

// Debounce funkce pro optimalizaci event listenerů
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle funkce pro scroll eventy
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Optimalizované scroll eventy
const optimizedScroll = throttle(function() {
    // Aktualizace pozice pro back-to-top tlačítko
    const backToTopBtn = document.getElementById('backToTop');
    if (backToTopBtn) {
        if (window.pageYOffset > 300) {
            backToTopBtn.classList.add('visible');
        } else {
            backToTopBtn.classList.remove('visible');
        }
    }

    // Zvýraznění aktivní sekce v navigaci
    updateActiveNavigation();
}, 100);

window.addEventListener('scroll', optimizedScroll);

function updateActiveNavigation() {
    const sections = document.querySelectorAll('section[id], main[id]');
    const navLinks = document.querySelectorAll('.nav-menu a');
    
    let currentSection = '';
    const scrollPosition = window.pageYOffset + 200;

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        
        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
            currentSection = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
        const href = link.getAttribute('href');
        if (href && href.includes(currentSection)) {
            link.classList.add('active');
        }
    });
}

// ====================================
// ERROR HANDLING
// ====================================

// Globální error handler
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
    
    // V produkčním prostředí by se error reportoval na server
    // reportError(e.error);
});

// Promise rejection handler
window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled Promise Rejection:', e.reason);
    
    // Prevent default browser behavior
    e.preventDefault();
});

// ====================================
// ACCESSIBILITY ENHANCEMENTS
// ====================================

// Keyboard navigation support
document.addEventListener('keydown', function(e) {
    // ESC klávesa pro zavření mobilního menu
    if (e.key === 'Escape') {
        const navToggle = document.querySelector('.nav-toggle');
        const navMenu = document.querySelector('.nav-menu');
        
        if (navMenu && navMenu.classList.contains('active')) {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        }

        // Zavření FAQ položek
        const openFaqItems = document.querySelectorAll('.faq-item.open');
        openFaqItems.forEach(item => {
            item.classList.remove('open');
        });
    }

    // Tab navigation enhancements
    if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation');
    }
});

// Remove keyboard navigation class on mouse interaction
document.addEventListener('mousedown', function() {
    document.body.classList.remove('keyboard-navigation');
});

// ====================================
// PERFORMANCE OPTIMIZATIONS
// ====================================

// Lazy loading pro obrázky (pokud by byly)
function initLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}

// Preload kritických zdrojů
function preloadCriticalResources() {
    const criticalCSS = document.createElement('link');
    criticalCSS.rel = 'prefetch';
    criticalCSS.href = 'style.css';
    document.head.appendChild(criticalCSS);
}

// ====================================
// BROWSER COMPATIBILITY
// ====================================

// Polyfill pro starší prohlížeče
if (!Element.prototype.closest) {
    Element.prototype.closest = function(selector) {
        var el = this;
        while (el) {
            if (el.matches(selector)) {
                return el;
            }
            el = el.parentElement;
        }
        return null;
    };
}

if (!Element.prototype.matches) {
    Element.prototype.matches = Element.prototype.msMatchesSelector || 
                                Element.prototype.webkitMatchesSelector;
}

// ====================================
// KONEC SOUBORU
// ====================================

console.log('🎓 Základní škola Žďár nad Sázavou - Website loaded successfully!');
